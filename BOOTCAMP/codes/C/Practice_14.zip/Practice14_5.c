#include <stdio.h>
#include <stdlib.h>

// Implement model 

void model(float *x){
// write your code below
}


// DO NOT MODIFY BELOW!
int main(){
    float x = 32.4;
    model(&x);
    printf("%f",x);
    return 0;
}