#include <stdio.h>

int main(void){
    int num;
    printf("Enter the number to be factorized: ");
    scanf("%d", &num);
    /* Your Code Here */
    
    return 0;
}

