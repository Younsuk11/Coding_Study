#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int numofones(int n) {
// Write your code below
}

// DO NOT MODIFY BELOW!
int main(int argc, char* argv[]) {
  int n = atoi(argv[1]);
  printf("%d", numofones(n));
  return 0;
}