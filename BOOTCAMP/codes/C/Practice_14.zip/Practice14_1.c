#include <stdio.h>

int main(void){
    /* Your Code Here */
    
    return 0; 
}


