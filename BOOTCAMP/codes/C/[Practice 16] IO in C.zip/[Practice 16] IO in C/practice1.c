#include <stdio.h>
#include <string.h>

/*
[Practice] 12 to 24 Time Conversion

Get input time in 12-hour clock and convert it into 24-hour clock.

Sample 1)
./run
Enter a time in 12-hour clock: 12:30 AM
Time converted in 24-hour clock: 00:30

Sample 2)
./run
Enter a time in 12-hour clock: 8:60 PM
Invalid Time!

Hint 1) You should use strcmp(str1, str2) and it returns 0 if they match. Note that '==' doesn't work to compare strings!
Hint 2) To print 1 => 01 and 11 => 11 (two digits), use '%02d' instead of '%d'.
*/


int main(void){
    
	/* Write your code here */

    




    
    
	return 0 ;
}
