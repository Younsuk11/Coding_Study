#include <stdio.h>
#define SIZE 10   // Define constant

void selection_sort(int L[], int size);  // Remember declaration!

int main(void){
    int L[SIZE] = {9, 8, 1, 6, 23, 4, 3, 11, 85, 0};
    
    printf("Before selection sort: ");
    for (int i = 0; i < SIZE; i++){
        printf("%d ", L[i]);
    } 
    printf("\n");

    selection_sort(L, SIZE);

    printf("After selection sort: ");
    for (int i = 0; i < SIZE; i++){
        printf("%d ", L[i]);
    } 
    printf("\n");

    return 0;
}

void selection_sort(int L[], int size){
    int smallest;
    int temp;

    /* Your code here*/

    ////////////////////
}

/*
<Test>
-> gcc p3.c -o p3
-> ./p3

<output>
Before selection sort: 9 8 1 6 23 4 3 11 85 0 
After selection sort: 0 1 3 4 6 8 9 11 23 85
*/

