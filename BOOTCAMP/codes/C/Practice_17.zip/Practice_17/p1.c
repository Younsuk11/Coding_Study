#include <stdio.h>
#include <stdlib.h>

/* define structures - Point, Rectangle */
/* Write your code here */

//////////////////////////

/* declare functions*/
float area(Rectangle rect);
float width(Rectangle rect);
float height(Rectangle rect);
Point centroid(Rectangle rect);

int main() {
    Point a = {10, 40}; // a.x = 10, a.y = 40
    Point b = {55, 10}; // b.x = 55, b.y = 10

    /* Write your code here */

    //////////////////////////    

    return 0;
}

/* define functions - area, width, height, centroid */
/* Write your code here */

//////////////////////////