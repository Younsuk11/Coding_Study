#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, sum = 0;
    int *array; // Pointer to a dynamically allocated memory area (heap)

    printf("Enter the number of elements: ");
    scanf("%d", &n);

    /* Write your code here */

    /////////////////////////

    return 0;
}